import logging
import asyncio
import aiogram.utils.markdown as md
from aiogram import Bot, Dispatcher, types
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Text, state
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.types import ParseMode, KeyboardButton, ReplyKeyboardMarkup
from aiogram.utils import executor
import psycopg2.extras
logging.basicConfig(level=logging.INFO)

API_TOKEN = '5790303201:AAHTDjrJUHFtP9YP-5vWT4f0jIUc5hHZdZU'


bot = Bot(token=API_TOKEN)

# подключение к бд postgres
hostname = 'localhost'
database = 'lost_things_fa'
username = 'aram'
pwd = 'admin'
port_id = 5432
conn = None
# For example use simple MemoryStorage for Dispatcher.
storage = MemoryStorage()
dp = Dispatcher(bot, storage=storage)

# настройка кнопок
btn_tech = KeyboardButton('Техника')
btn_clothes = KeyboardButton('Одежда')
btn_acc = KeyboardButton('Аксессуары')
btn_pers = KeyboardButton('Личные вещи')
other_menu = ReplyKeyboardMarkup(resize_keyboard=True).add(btn_tech, btn_clothes, btn_pers, btn_acc)


btn_1 = KeyboardButton('Потерял')
btn_2 = KeyboardButton('Нашёл')
role_menu = ReplyKeyboardMarkup(resize_keyboard=True).add(btn_1, btn_2)



# States
class Form(StatesGroup):
    time = State()
    place = State()
    current = State()
    category = State()
    photo = State()

class Form2(StatesGroup):
    categ = State()

# стартовая кнопка
@dp.message_handler(commands='Start')
async def second_handler(message: types.Message):
    await message.reply(f"👋 Привет, {message.from_user.first_name}! Какая функция тебя интересует?", reply_markup=role_menu)



# выбор функционала
@dp.message_handler()
async def second_handler(message: types.Message):
    if message.text == "Нашёл":
        await cmd_start(message)

    elif message.text == "Потерял":
        await lost_func(message)


# выбор категории
@dp.message_handler()
async def lost_func(message: types.Message):
    await Form2.categ.set()
    await message.reply("Выберите категорию предмета", reply_markup=other_menu)

# извлечение данных из бд
@dp.message_handler(state=Form2.categ)
async def cat_ch(message: types.Message, state: FSMContext):

    try:
        with psycopg2.connect(
                host=hostname,
                dbname=database,
                user=username,
                password=pwd,
                port=port_id) as conn:

            with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
                insert_script = f'''SELECT disc_time, disc_loc, curr_loc, item_image  FROM item
                                    WHERE category = '{message.text}';'''

                cur.execute(insert_script)
                records = cur.fetchall()
                print(records)

    except Exception as error:
        print(error)
    finally:
        if conn is not None:
            conn.close()
    for item in records:
       await message.answer_photo(caption=f"Вещь найдена:{item[0]}\nГде:{item[1]}\nСейчас она находится:{item[2]}",
                                  photo = item[3])
    await state.finish()

    await message.reply(
        "Для перехода к началу нажми /start "
    )

# сбор информации от пользователя
@dp.message_handler()
async def cmd_start(message: types.Message):
    """
    Conversation's entry point
    """

    await Form.time.set()

    await message.reply(f"Когда ты нашёл вещь? (Дата и время)")


@dp.message_handler(state=Form.time)
async def process_name(message: types.Message, state: FSMContext):

    async with state.proxy() as data:
        data['time'] = message.text

    await Form.next()
    await message.reply("Где вы обнаружили вещь?")

@dp.message_handler(state=Form.place)
async def process_name(message: types.Message, state: FSMContext):

    async with state.proxy() as data:
        data['place'] = message.text

    await Form.next()
    await message.reply("Где она сейчас?")


@dp.message_handler(state=Form.current)
async def process_age(message: types.Message, state: FSMContext):
    # Update state and data

    async with state.proxy() as data:
        data['current'] = message.text

    await Form.next()


    # Configure ReplyKeyboardMarkup

    await message.reply("Выберите категорию предмета", reply_markup=other_menu)



@dp.message_handler(state=Form.category)
async def process_gender(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
        data['category'] = message.text

    await Form.next()
    await message.reply("Загрузите фотографию предмета.")

@dp.message_handler(state=Form.photo, content_types=['photo'])
async def handle_photo(message: types.Message, state: FSMContext):


    async with state.proxy() as data:
        data['photo'] = message.photo[-1].file_id


        markup = types.ReplyKeyboardRemove()


        await message.reply(
            "Предмет успешно добавлен. Для перехода к началу нажми /start "
        )

        # запись в бд
        try:
            with psycopg2.connect(
                    host=hostname,
                    dbname=database,
                    user=username,
                    password=pwd,
                    port=port_id) as conn:

                with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
                    insert_script = f'''INSERT INTO item (category, disc_time, disc_loc, curr_loc, item_image)
                     VALUES ('{data['category']}', '{data['time']}', '{data['place']}', '{data['current']}', '{data['photo']}' )'''

                    cur.execute(insert_script)


        except Exception as error:
            print(error)
        finally:
            if conn is not None:
                conn.close()


    # Finish conversation
    await state.finish()


if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)