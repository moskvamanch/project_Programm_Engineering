# from aiogram import Bot, types
# from aiogram.dispatcher import Dispatcher
# from aiogram.utils import executor
# from aiogram.types import ContentType, Message, KeyboardButton, ReplyKeyboardMarkup, InlineKeyboardButton, \
#     InlineKeyboardMarkup
#
# TOKEN = '5848603840:AAGaK_8hHlB0EdvGWmcopw0PNCOQsg9TUG8'
#
# bot = Bot(token=TOKEN)
# dp = Dispatcher(bot)
# button_hi = KeyboardButton('Привет! 👋')
# greet_kb = ReplyKeyboardMarkup()
# greet_kb.add(button_hi)
#
# @dp.message_handler(commands=['start'])
# async def begin(message: types.Message):
#     markup = InlineKeyboardMarkup()
#     but1 = InlineKeyboardButton("Я потерял вещь", callback_data="but1")
#     but2 = InlineKeyboardButton("Я нашёл вещь", callback_data="but2")
#     markup.add(but1,but2)
#     await bot.send_message(message.chat.id, "Привет! \nТы потерял и нашёл?", reply_markup=markup)
#
# @dp.callback_query_handler(lambda c: c.data == "but1")
# async def buffon_reaction(call: types.callback_query):
#     await bot.answer_callback_query(call.id)
#
#
# # @dp.message_handler(commands=['start'])
# # async def begin(message: types.Message):
# #     await bot.send_message(message.chat.id, "Приветствую!", reply_markup=kb.greet_kb)
# #
# # @dp.message_handler(commands=['photo'])
# # async def cats(message: types.Message):
# #     with open('/Users/aram/PycharmProjects/lost_things_bot/venv/passport.jpg', 'rb') as photo:
# #
# #
# #         await message.reply_photo(photo, caption='Найден: ауд.326/ Пт 25.11 12.00 \n Текущее местоположение: КПП')
# #
# executor.start_polling(dp)