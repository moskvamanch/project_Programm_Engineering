host = '127.0.0.1'
user = 'aram'
database = 'lost_things_fa'