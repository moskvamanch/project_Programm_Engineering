from aiogram.types import ReplyKeyboardMarkup, KeyboardButton  # pip install aiogram
from aiogram import Dispatcher, Bot, executor, types
from random import randint, choice
from string import ascii_letters, digits, punctuation

import psycopg2
import psycopg2.extras

hostname = 'localhost'
database = 'lost_things_fa'
username = 'aram'
pwd = 'admin'
port_id = 5432
conn = None

API_TOKEN = '5790303201:AAHTDjrJUHFtP9YP-5vWT4f0jIUc5hHZdZU'

# инициализация ботика...
bot = Bot(token=API_TOKEN)
dispatcher = Dispatcher(bot)

# Создание клавиатуры
btn_random = KeyboardButton("Я нашёл")
btn_pass = KeyboardButton('Я потерял')
btn_other = KeyboardButton("🔷 Другое")

main_menu = ReplyKeyboardMarkup(resize_keyboard=True).add(btn_random, btn_pass, btn_other)

btn_tech = KeyboardButton('Техника')
btn_clothes = KeyboardButton('Одежда')
btn_acc = KeyboardButton('Аксессуары')
btn_pers = KeyboardButton('Личные вещи')

other_menu = ReplyKeyboardMarkup(resize_keyboard=True).add(btn_tech, btn_clothes,btn_pers, btn_acc)




@dispatcher.message_handler(commands=['start'])
async def start(message: types.Message):
    await bot.send_message(message.from_user.id, f"👋 Привет, {message.from_user.first_name}! \nВы потеряли или нашли вещь?", reply_markup=main_menu)








# # @dispatcher.message_handler()
# # async def messages(message: types.Message):
# #     if message.text == 'Я нашёл':
# #         await bot.send_message(message.from_user.id, 'Выберите категорию...', reply_markup=other_menu)
# #     elif message.text == 'Я потерял':
# #         await bot.send_message(message.from_user.id, '🔷 Открываю...', reply_markup=other_menu)
#
# @dispatcher.message_handler(commands=['Я нашёл'])
# async def disc_person(message: types.Message):
#     await message.answer(text='Выберите категорию...')


if __name__ == '__main__':
    executor.start_polling(dispatcher, skip_updates=True)