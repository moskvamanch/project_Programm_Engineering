import psycopg2
import psycopg2.extras

hostname = 'localhost'
database = 'lost_things_fa'
username = 'aram'
pwd = 'admin'
port_id = 5432
conn = None

try:
    with psycopg2.connect(
                host = hostname,
                dbname = database,
                user = username,
                password = pwd,
                port = port_id) as conn:

        with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:



            insert_script  = '''INSERT INTO item (category)
             VALUES ('Одежда')'''

            cur.execute(insert_script)


except Exception as error:
    print(error)
finally:
    if conn is not None:
        conn.close()



        #
        # try:
        #     with psycopg2.connect(
        #             host=hostname,
        #             dbname=database,
        #             user=username,
        #             password=pwd,
        #             port=port_id) as conn:
        #
        #         with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
        #             create_script = '''INSERT INTO item (category)
        #                                 VALUES ('Техника');'''
        #             cur.execute(create_script)
        #
        #
        #
        # except Exception as error:
        #     print(error)
        # finally:
        #     if conn is not None:
        #         conn.close()